# ng-students
aplicación sistema de estudiantes en angularjs
