(function () {
   'use strict';
   // declaramos el módulo de estudiantes
   // notese el arreglo como segundo párametro al método module, indica que estamos creando un nuevo módulo
   angular.module('students', []);

}());